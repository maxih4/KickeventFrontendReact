import React, {useEffect, useState} from 'react';
import {useNavigate, useLocation, useParams} from "react-router-dom"
import axios from "axios";


function SingleEvent(props) {
    const navigation = useNavigate()
    const location = useLocation()
    const {id} = useParams()
    const [event, setEvent] = useState({title: "",content: ""})


    useEffect(() => {
        const getEvent = async () =>
            await axios.get("https://localhost:8443/api/event/" + id)
                .then((res) => {
                    setEvent(res.data)

                }, (error) => {
                    console.log("Fehler bei der Anfrage " + error)
                })
        getEvent()
    }, []);


    return (


        <div className="container">
            <div className="jumbotron mt-3">
                <h1>{event.title}</h1>
                <p className="lead">{event.content}</p>
                <a className="btn btn-lg btn-primary" href="/docs/4.3/components/navbar/" role="button">View navbar docs
                    »</a>
            </div>
        </div>




)
;
}

export default SingleEvent;